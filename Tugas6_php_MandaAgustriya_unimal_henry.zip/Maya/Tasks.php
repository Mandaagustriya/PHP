<!-- ======= Portfolio Section ======= -->
<section id="portfolio" class="portfolio section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Tasks</h2>
          <p>this is assigment academy fullstack web developer</p>
        </div>
        <div class="row" data-aos="fade-up">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-html">Html</li>
              <li data-filter=".filter-js">JavaScript</li>
              <li data-filter=".filter-php">PHP</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">
            <!--tugas html -->
                <div class="col-lg-4 col-md-6 portfolio-item filter-html">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-1.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-1.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas html 1"><i class="bx bx-plus"></i></a>
                           
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-html">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-2.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-2.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas html 2"><i class="bx bx-plus"></i></a>
                           
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-html">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-3.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-3.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas html 3"><i class="bx bx-plus"></i></a>
                            
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-html">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-4.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-4.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas html 4"><i class="bx bx-plus"></i></a>
                           
                        </div>
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 portfolio-item filter-html">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-6.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-6.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas html 6"><i class="bx bx-plus"></i></a>
                           
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-html">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-7.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-7.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas html 7"><i class="bx bx-plus"></i></a>
                           
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-html">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-8.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-8.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas html 8"><i class="bx bx-plus"></i></a>
                           
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 portfolio-item filter-html">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-9.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-9.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas html 9"><i class="bx bx-plus"></i></a>
                            
                        </div>
                    </div>
                </div>
         <!--akhir tgs html -->
          <!--tugas js -->
                 <div class="col-lg-4 col-md-6 portfolio-item filter-js">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-a.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-a.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas js 1"><i class="bx bx-plus"></i></a>
                           
                        </div>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 portfolio-item filter-js">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-b.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-b.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas js 2"><i class="bx bx-plus"></i></a>
                            
                        </div>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 portfolio-item filter-js">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-c.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-c.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas js 3"><i class="bx bx-plus"></i></a>
                            
                        </div>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 portfolio-item filter-js">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-d.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-d.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas js 4"><i class="bx bx-plus"></i></a>
                          
                        </div>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 portfolio-item filter-js">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-e.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-e.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas js 5"><i class="bx bx-plus"></i></a>
                            
                        </div>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 portfolio-item filter-js">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-f.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-f.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas js 6"><i class="bx bx-plus"></i></a>
                            
                        </div>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 portfolio-item filter-js">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-g.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-g.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas js 7"><i class="bx bx-plus"></i></a>
                           
                        </div>
                    </div>
                  </div>
          <!--akhir tugas js -->

          <!--tugas php -->
                    <div class="col-lg-4 col-md-6 portfolio-item filter-php">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-a1.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-a1.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas php 1"><i class="bx bx-plus"></i></a>
                           
                        </div>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 portfolio-item filter-php">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-a2.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-a2.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas php 2"><i class="bx bx-plus"></i></a>
                          
                        </div>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 portfolio-item filter-php">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-a3.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-c.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas php 3"><i class="bx bx-plus"></i></a>
                            
                        </div>
                    </div>
                  </div>

                  <div class="col-lg-4 col-md-6 portfolio-item filter-php">
                    <div class="portfolio-wrap">
                    <img src="assets/img/pic/tasks-a4.png" class="img-fluid" alt="">
                        <div class="portfolio-links">
                            <a href="assets/img/pic/tasks-a4.png" data-gallery="portfolioGallery" class="portfolio-lightbox" title="tugas php 4"><i class="bx bx-plus"></i></a>
                        </div>
                    </div>
                  </div>
          <!--akhir tugas php -->
        
        </div>

      </div>
    </section><!-- End Portfolio Section -->