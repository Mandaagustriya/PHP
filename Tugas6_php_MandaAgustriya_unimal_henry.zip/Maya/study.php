 <section id="resume" class="resume">
     <div class="container">

         <div class="section-title">
             <h2>Resume</h2>
             <p>Saya seorang mahasiswi di Universitas Malikussaleh Jurusan informatika angkatan 2020 dan saat ini
                saya menjalani semester 5 di kampus saya, saya ngekos di daerah blang pulo lhokseumawe, Nangroe aceh darussalam. 
                saya asli dari peureulak, aceh timur. saya 3 bersaudara dan saya anak ke 3.</p>
         </div>

         <div class="row">
             <div class="col-lg-6" data-aos="fade-up">
                 <h3 class="resume-title">Sumary</h3>
                 <div class="resume-item pb-0">
                     <h4>Manda Agustriya</h4>
                     <p><em>"Kamu adalah kesuksesan sejati jika kamu dapat mempercayai diri sendiri, mencintai diri sendiri, dan menjadi diri sendiri.".</em></p>
                     <ul>
                         <li>Lhokseumawe, Nangroe Aceh DArussalam</li>
                         <li>081264629029</li>
                         <li>mandaagustriya@gmail.com</li>
                     </ul>
                 </div>

                 <h3 class="resume-title">LEARNING HISTORY</h3>
                 <div class="resume-item">
                     <h4>MIN RANTO PEUREULAK</h4>
                     <h5>2008 - 2014</h5>
                 </div>
                 <div class="resume-item">
                     <h4>MTSN RANTO PEURELAK</h4>
                     <h5>2014 - 2017</h5>
                 </div>
                 </div> 
             <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
                 <h3 class="resume-title"></h3>
                 <div class="resume-item">
                     <h4>SMAN 1 RANTO PEUREULAK</h4>
                     <h5>2017 - 2020</h5>
                     <p><em>SMAN 1 RANTO PEUREULAK </em></p>
                 </div>
                 <div class="resume-item">
                     <h4>Universitas Malikussaleh</h4>
                     <h5>2020 - sekarang</h5>
                     <p><em>Universitas Malikussaleh</em></p>
                 </div>
             </div>
         </div>

     </div>
 </section>