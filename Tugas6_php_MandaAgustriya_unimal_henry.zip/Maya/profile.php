<div class="profile">
    <img src="assets/img/profile-img.jpeg" alt="" class="img-fluid rounded-circle">
    <h1 class="text-light"><a href="index.html">Manda Agustriya</a></h1>
    <div class="social-links mt-3 text-center">
        <a href="https://web.facebook.com/manda.agustriya.75" target="_blank" class="facebook"><i
                class="bx bxl-facebook"></i></a>
        <a href="https://www.instagram.com/manda.agstrya19/" target="_blank" class="instagram"><i 
                class="bx bxl-instagram"></i></a>
        <a href="https://www.tiktok.com/@itsme_1902?lang=id-ID" target="_blank" class="tiktok"><i 
                class="bx bxl-tiktok"></i></a>
        <a href="https://https://github.com/Mandaagustriya" target="_blank" class="github"><i 
                class="bx bxl-github"></i></a>
       
    </div>
</div>